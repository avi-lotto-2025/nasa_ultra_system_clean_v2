import random

class KiraEngine:
    def __init__(self, history_loader):
        self.history = history_loader
        self.patterns = self._find_patterns()

    def _find_patterns(self):
        patterns = {}
        for draw in self.history.all():
            nums = tuple(draw["numbers"])
            patterns[nums] = patterns.get(nums,0)+1
        return patterns

    def pick_numbers(self):
        if not self.patterns:
            return [random.randint(1,37) for _ in range(6)] + [random.randint(1,7)]
        best = max(self.patterns, key=self.patterns.get)
        bonus = random.randint(1,7)
        return list(best) + [bonus]

    def export(self):
        return {
            "total_patterns": len(self.patterns),
            "top_pattern": max(self.patterns, key=self.patterns.get)
        }
