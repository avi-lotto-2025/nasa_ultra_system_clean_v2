import json
import os

class HistoryLoader:
    def __init__(self, path="history_full.json"):
        if not os.path.exists(path):
            raise FileNotFoundError(f"לא נמצא קובץ היסטוריה: {path}")
        with open(path, "r", encoding="utf-8") as f:
            self.data = json.load(f)

    def all(self):
        return self.data

    def size(self):
        return len(self.data)

    def exists(self, draw_obj):
        return any(
            d["draw"] == draw_obj["draw"] and
            d["numbers"] == draw_obj["numbers"] and
            d["bonus"] == draw_obj["bonus"]
            for d in self.data
        )

    def add_entry(self, draw_obj):
        self.data.append(draw_obj)
        self._save()

    def _save(self):
        with open("history_full.json", "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
