import random

class PredictionEngine:
    def __init__(self, stats_engine, kira_engine, quantum_engine):
        self.stats = stats_engine
        self.kira = kira_engine
        self.quantum = quantum_engine

    def _fix(self, nums):
        main = [max(1,min(37,x)) for x in nums[:-1]]
        bonus = max(1,min(7,nums[-1]))
        return main + [bonus]

    def _combine(self):
        s = self.stats.pick_numbers()
        k = self.kira.pick_numbers()
        q = self.quantum.pick_numbers()
        final = [
            int((s[i]+k[i]+q[i])/3) for i in range(6)
        ]
        bonus = int((s[6]+k[6]+q[6])/3)
        return self._fix(final+[bonus])

    def generate(self):
        try:
            return self._combine()
        except:
            return [random.randint(1,37) for _ in range(6)] + [random.randint(1,7)]

    def generate_backups(self, c):
        return [self.generate() for _ in range(c)]
