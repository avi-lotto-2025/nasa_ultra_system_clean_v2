import random

class QuantumEngine:
    def pick_numbers(self):
        main = [random.randint(1,37) for _ in range(6)]
        bonus = random.randint(1,7)
        return main + [bonus]

    def export(self):
        return {"quantum_seed": random.random()}
