import requests

class OfficialFetcher:
    def fetch_latest(self):
        try:
            url = "https://www.pais.co.il/lotto/lastresults.aspx"
            r = requests.get(url,timeout=4)
            if r.status_code != 200:
                return None
            return None
        except:
            return None
