from history_loader import HistoryLoader
from stats_engine import StatsEngine
from kira_engine import KiraEngine
from quantum_engine import QuantumEngine
from prediction_engine import PredictionEngine
from official_fetch_engine import OfficialFetcher
from auto_heal import AutoHeal

class EngineMaster:
    def __init__(self):
        self.history = HistoryLoader()
        self.fetcher = OfficialFetcher()
        self.stats = StatsEngine(self.history)
        self.kira = KiraEngine(self.history)
        self.quantum = QuantumEngine()
        self.prediction = PredictionEngine(self.stats,self.kira,self.quantum)
        self.auto_heal = AutoHeal()

    def update(self):
        try:
            latest = self.fetcher.fetch_latest()
            if latest and not self.history.exists(latest):
                self.history.add_entry(latest)
                return {"updated":True}
            return {"updated":False}
        except:
            return {"updated":False}

    def generate_full(self):
        try:
            upd = self.update()
            return {
                "primary": self.prediction.generate(),
                "backups": self.prediction.generate_backups(5),
                "stats": self.stats.export(),
                "kira": self.kira.export(),
                "quantum": self.quantum.export(),
                "history": self.history.size(),
                "updated": upd
            }
        except Exception as e:
            self.auto_heal.repair(str(e))
            return {"error":True, "fix": self.auto_heal.last_action}
