from flask import Flask, jsonify
from engine_master import EngineMaster

app = Flask(__name__)
engine = EngineMaster()

@app.route("/forecast")
def get_forecast():
    return jsonify(engine.generate_full())
