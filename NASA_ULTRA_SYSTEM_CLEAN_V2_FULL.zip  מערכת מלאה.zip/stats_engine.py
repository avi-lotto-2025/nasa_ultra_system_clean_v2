from collections import Counter

class StatsEngine:
    def __init__(self, history_loader):
        self.history = history_loader
        self.counts_main = Counter()
        self.counts_bonus = Counter()
        self._analyze()

    def _analyze(self):
        data = self.history.all()
        for draw in data:
            for n in draw["numbers"]:
                self.counts_main[n] += 1
            self.counts_bonus[draw["bonus"]] += 1

        if len(self.counts_main) == 0:
            for i in range(1,38):
                self.counts_main[i] = 1
            for j in range(1,8):
                self.counts_bonus[j] = 1

    def pick_numbers(self):
        top_main = [n for n,_ in self.counts_main.most_common(6)]
        top_bonus = self.counts_bonus.most_common(1)[0][0]
        return top_main + [top_bonus]

    def export(self):
        return {
            "top_main": self.counts_main.most_common(10),
            "top_bonus": self.counts_bonus.most_common(3),
            "history_size": self.history.size()
        }
