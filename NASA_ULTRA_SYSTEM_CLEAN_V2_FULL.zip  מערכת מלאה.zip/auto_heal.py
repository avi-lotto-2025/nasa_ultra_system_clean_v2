class AutoHeal:
    def __init__(self):
        self.last_action = None

    def repair(self, err):
        self.last_action = f"Auto-Heal triggered: {err}"
